from __future__ import annotations

from typing import Any

import requests


class VisionService:
    def analyze_image(self, image_source: str) -> str:
        if image_source.startswith(("http://", "https://")):
            response = requests.get(image_source, timeout=30)
            response.raise_for_status()
            return f"Image fetched successfully from {image_source}"
        return f"Image available locally at {image_source}"
