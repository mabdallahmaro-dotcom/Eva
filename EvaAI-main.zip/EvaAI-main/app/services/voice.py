from __future__ import annotations

from typing import Any

import speech_recognition as sr


class VoiceService:
    def transcribe(self, audio_path: str) -> str:
        recognizer = sr.Recognizer()
        with sr.AudioFile(audio_path) as source:
            audio = recognizer.record(source)
        return recognizer.recognize_google(audio)
