from __future__ import annotations

from typing import Any

import pytesseract
from PIL import Image


class OCRService:
    def extract_text(self, image_path: str) -> str:
        image = Image.open(image_path)
        return pytesseract.image_to_string(image)
