from __future__ import annotations

from datetime import datetime
from typing import Iterable

from .memory import MemoryStore


class ReminderService:
    def __init__(self, memory_store: MemoryStore) -> None:
        self.memory_store = memory_store

    def get_due_reminders(self, now: datetime) -> list[object]:
        return self.memory_store.list_due_reminders(now)
