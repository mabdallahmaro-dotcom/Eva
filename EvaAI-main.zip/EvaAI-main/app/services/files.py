from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd
from docx import Document
from PyPDF2 import PdfReader


class DocumentService:
    def extract_text_from_file(self, file_path: str) -> str:
        suffix = Path(file_path).suffix.lower()
        if suffix == ".pdf":
            return self.read_pdf(file_path)
        if suffix == ".docx":
            return self.read_docx(file_path)
        if suffix in {".xlsx", ".xls"}:
            return self.read_excel(file_path)
        return Path(file_path).read_text(encoding="utf-8") if Path(file_path).exists() else ""

    def read_pdf(self, file_path: str) -> str:
        reader = PdfReader(file_path)
        texts = [page.extract_text() or "" for page in reader.pages]
        return "\n".join(texts)

    def read_docx(self, file_path: str) -> str:
        document = Document(file_path)
        return "\n".join(paragraph.text for paragraph in document.paragraphs if paragraph.text)

    def read_excel(self, file_path: str) -> str:
        df = pd.read_excel(file_path)
        return df.to_markdown(index=False)

    def write_excel(self, file_path: str, rows: list[dict[str, Any]]) -> str:
        df = pd.DataFrame(rows)
        df.to_excel(file_path, index=False)
        return str(Path(file_path).resolve())

    def write_docx(self, file_path: str, text: str) -> str:
        doc = Document()
        doc.add_paragraph(text)
        doc.save(file_path)
        return str(Path(file_path).resolve())
