from __future__ import annotations

import requests


class WebSearchService:
    def search(self, query: str, *, api_key: str | None = None) -> str:
        if not api_key:
            return "Web search is disabled. Provide a search API key."

        response = requests.get(
            "https://serpapi.com/search",
            params={"q": query, "api_key": api_key},
            timeout=30,
        )
        response.raise_for_status()
        data = response.json()
        return data.get("answer_box", {}).get("answer") or data.get("organic_results", [{}])[0].get("snippet", "No results")
