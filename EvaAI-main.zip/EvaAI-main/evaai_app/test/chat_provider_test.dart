import 'package:flutter_test/flutter_test.dart';
import 'package:evaai/features/chat/presentation/providers/chat_provider.dart';

void main() {
  test('chat notifier can initialize with empty state', () {
    final notifier = ChatNotifier(null as dynamic, null as dynamic);
    expect(notifier.state, isEmpty);
  });
}
